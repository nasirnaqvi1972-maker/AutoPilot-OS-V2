﻿import os
import sys
import shutil
from pathlib import Path
from bs4 import BeautifulSoup

sys.path.append(str(Path(__file__).resolve().parent))
from core.blogger_publisher import publish_post
from core.image_curator import curate_images

V2_ROOT = Path(__file__).resolve().parent
PENDING_DIR = V2_ROOT / "content" / "pending"
PROCESSED_DIR = V2_ROOT / "content" / "processed"
FAILED_DIR = V2_ROOT / "content" / "failed"

def process_post(html_path):
    print(f"\n==================================================")
    print(f"PROCESSING: {html_path.name}")
    print(f"==================================================")
    
    # 1. Read the HTML
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
        
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # 2. Extract Title from <h1>
    h1 = soup.find('h1')
    title = h1.get_text(strip=True) if h1 else html_path.stem.replace('-', ' ').title()
    print(f"  [main] Title: {title}")
    
    # 3. Curate Images (This downloads images and creates _output.html)
    img_folder = PROCESSED_DIR / html_path.stem
    curate_images(html_path, img_folder)
    
    # 4. Publish (Using the newly curated HTML!)
    curated_html_path = img_folder / "_output.html"
    success = publish_post(
        html_path=curated_html_path,
        img_folder=img_folder,
        title=title,
        labels=[]
    )
    
    if success:
        shutil.move(str(html_path), str(PROCESSED_DIR / html_path.name))
        print(f"  ✅ SUCCESS: {html_path.name} moved to processed.")
    else:
        shutil.move(str(html_path), str(FAILED_DIR / html_path.name))
        print(f"  ❌ FAILED: {html_path.name} moved to failed.")

def main():
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    FAILED_DIR.mkdir(parents=True, exist_ok=True)

    pending_files = list(PENDING_DIR.glob("*.html"))
    
    if not pending_files:
        print("No .html files found in pending.")
        return

    print(f"Found {len(pending_files)} HTML posts to process.")
    
    for i, html_file in enumerate(pending_files, 1):
        print(f"\n[{i}/{len(pending_files)}] Processing {html_file.name}...")
        process_post(html_file)

if __name__ == "__main__":
    main()
