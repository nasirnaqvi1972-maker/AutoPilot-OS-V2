import os
import sys
import json
import time
import csv
import re
import requests
from datetime import datetime
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, r"D:\Projects\AutoPilot_OS_v2")
from core.blogger_publisher import get_blogger_service

DRY_RUN = False
BACKUP_DIR = os.path.join(r"D:\Projects\AutoPilot_OS_v2", "backups")
REPORT_DIR = os.path.join(r"D:\Projects\AutoPilot_OS_v2", "reports")

def setup_dirs():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(REPORT_DIR, exist_ok=True)

def check_link(url):
    try:
        res = requests.head(url, timeout=5, allow_redirects=True)
        return url, res.status_code
    except Exception:
        return url, 404

def run_curator():
    setup_dirs()
    service = get_blogger_service()
    blog = service.blogs().getByUrl(url='https://dustanddynasty.blogspot.com').execute()
    blog_id = blog['id']

    print("Fetching all posts...")
    all_posts = []
    tok = None
    while True:
        res = service.posts().list(blogId=blog_id, maxResults=100, pageToken=tok).execute()
        all_posts.extend(res.get('items', []))
        tok = res.get('nextPageToken')
        if not tok: break

    print(f"Found {len(all_posts)} total posts.")

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    backup_file = os.path.join(BACKUP_DIR, f"pre_curator_{timestamp}.json")

    print(f"Creating backup to {backup_file}...")
    backup_data = []
    for p in all_posts:
        try:
            full = service.posts().get(blogId=blog_id, postId=p['id'], view="AUTHOR", fetchBody=True).execute()
            backup_data.append({"id": p['id'], "title": p.get('title', ''), "content": full.get('content', ''), "searchDescription": full.get('searchDescription', '')})
        except Exception as e:
            print(f"  Backup failed for {p['id']}: {e}")

    with open(backup_file, 'w', encoding='utf-8') as f:
        json.dump(backup_data, f, indent=4)
    print("Backup complete!")

    print("Extracting internal links...")
    internal_links = set()
    for p in all_posts:
        soup = BeautifulSoup(p.get('content', ''), 'html.parser')
        for a in soup.find_all('a', href=True):
            href = a['href']
            if 'dustanddynasty.blogspot.com' in href or href.startswith('/'):
                if href.startswith('/'):
                    href = f"https://dustanddynasty.blogspot.com{href}"
                href = href.split('#')[0]
                internal_links.add(href)

    print(f"Checking {len(internal_links)} unique internal links...")
    broken_links = set()
    with ThreadPoolExecutor(max_workers=10) as executor:
        for url, status in executor.map(check_link, internal_links):
            if status >= 400:
                broken_links.add(url)
                print(f"  Broken: {url} ({status})")

    print(f"Found {len(broken_links)} broken links.")

    report_data = []
    fixed_meta = fixed_h1 = fixed_links = 0

    for i, p in enumerate(all_posts, 1):
        try:
            time.sleep(0.3)
            post_id = p['id']
            title = p.get('title', '')[:40]
            full = service.posts().get(blogId=blog_id, postId=post_id, view="AUTHOR", fetchBody=True).execute()
            soup = BeautifulSoup(full.get('content', ''), 'html.parser')
            changed = False
            issues = []
            meta_desc = full.get('searchDescription', '')

            if not meta_desc:
                first_p = soup.find('p')
                if first_p:
                    text = first_p.get_text(" ", strip=True)
                    clean = re.sub(r'\s+', ' ', text)
                    if len(clean) > 150:
                        clean = clean[:147].rsplit(' ', 1)[0] + "..."
                    if clean:
                        meta_desc = clean
                        changed = True
                        fixed_meta += 1
                        issues.append("Missing Meta Description -> Generated")

            h1_tags = soup.find_all('h1')
            if len(h1_tags) > 1:
                for extra in h1_tags[1:]:
                    extra.name = 'h2'
                changed = True
                fixed_h1 += 1
                issues.append("Multiple H1s -> Demoted to H2")

            for a in soup.find_all('a', href=True):
                href = a['href']
                if href.startswith('/'):
                    href = f"https://dustanddynasty.blogspot.com{href}"
                href = href.split('#')[0]
                if href in broken_links:
                    a.unwrap()
                    changed = True
                    fixed_links += 1
                    issues.append(f"Broken Link Removed: {href}")

            if changed:
                if DRY_RUN:
                    print(f"  [DRY RUN] Would fix: {title}")
                else:
                    body = {'id': post_id, 'title': p.get('title'), 'content': str(soup), 'searchDescription': meta_desc}
                    if p.get('labels'):
                        body['labels'] = p['labels']
                    service.posts().patch(blogId=blog_id, postId=post_id, body=body).execute()
                    print(f"  [{i}/{len(all_posts)}] FIXED: {title}")
                for issue in issues:
                    report_data.append({"post_id": post_id, "title": title, "issue": issue, "action": "DRY_RUN" if DRY_RUN else "FIXED"})
        except Exception as e:
            print(f"  ERROR on {title}: {e}")

    report_file = os.path.join(REPORT_DIR, f"curator_report_{timestamp}.csv")
    with open(report_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["post_id", "title", "issue", "action"])
        writer.writeheader()
        writer.writerows(report_data)

    print("=" * 50)
    print(f"CURATOR COMPLETE! {'(DRY RUN)' if DRY_RUN else '(LIVE)'}")
    print(f"  Meta Descriptions: {fixed_meta}")
    print(f"  Multiple H1s: {fixed_h1}")
    print(f"  Broken Links: {fixed_links}")
    print(f"  Report: {report_file}")
    print("=" * 50)

if __name__ == "__main__":
    run_curator()
