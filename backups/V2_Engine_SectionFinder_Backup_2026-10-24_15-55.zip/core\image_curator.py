﻿import os, re, json, time, shutil, tempfile, urllib.parse, urllib.request, html
from pathlib import Path
from bs4 import BeautifulSoup
import torch
import open_clip
from PIL import Image
import cv2
import numpy as np
import imagehash
from core.section_finder import find_sections, insert_image

RELAY_URL = "https://wikimedia-relay.nasirabbasnaqvi.workers.dev"
RELAY_TOKEN = "ddd-secret-2026"

def _relay_get(target_url, timeout=30):
    params = urllib.parse.urlencode({"url": target_url, "token": RELAY_TOKEN})
    req = urllib.request.Request(f"{RELAY_URL}?{params}", headers={"User-Agent": "DustAndDynastyBot/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()

def _relay_json(base_url, **params):
    params["format"] = "json"
    api_url = base_url + "?" + urllib.parse.urlencode(params)
    try:
        raw = _relay_get(api_url)
        return json.loads(raw.decode('utf-8'))
    except Exception:
        return {}

_model = None
_preprocess = None
_tokenizer = None

def _load_clip():
    global _model, _preprocess, _tokenizer
    if _model is None:
        _model, _, _preprocess = open_clip.create_model_and_transforms('ViT-B-32', pretrained='laion2b_s34b_b79k')
        _tokenizer = open_clip.get_tokenizer('ViT-B-32')
        _model.eval()

# FIX: Using keyword arguments and with Image.open()
def contrastive_clip_score(image_path, subject, heading, snippet):
    _load_clip()
    pos_prompt = f"A photograph of {subject}, showing {snippet}."
    negatives = [
        "A photograph of a different monument.", "A tourist selfie.",
        "A street sign or informational plaque.", "A map or architectural diagram.",
        "A black and white photograph", "A historical archive photo", "A drawing or painting", "A modern building.",
    ]
    try:
        with Image.open(image_path) as im:
            img = _preprocess(im.convert("RGB")).unsqueeze(0)
        text = _tokenizer([pos_prompt] + negatives)
        with torch.no_grad():
            img_feat = _model.encode_image(img)
            txt_feat = _model.encode_text(text)
            img_feat /= img_feat.norm(dim=-1, keepdim=True)
            txt_feat /= txt_feat.norm(dim=-1, keepdim=True)
            sims = (img_feat @ txt_feat.T).squeeze(0).tolist()
        pos = sims[0]
        max_neg = max(sims[1:])
        print(f"      [clip] pos={pos:.3f} max_neg={max_neg:.3f} margin={pos-max_neg:.3f}")
        return pos > 0.20 and (pos - max_neg) > 0.02
    except Exception as e:
        print(f"      [clip] error: {e}")
        return False

BAD_WORDS = re.compile(r"\b(sign|signage|selfie|poster|logo|map|plan|diagram|flag|coat of arms|plaque|menu|ticket|screenshot|scan|stamp|coin|banner|icon|bus|train|bw|black_and_white|archive|historical)\b", re.I)

def norm_title(t):
    return re.sub(r"[_\-\.\(\)]+", " ", re.sub(r"^File:|\.\w{3,4}$", "", t))

def passes_meta_filter(page, min_w=1280, min_h=720):
    if 'imageinfo' not in page: return False
    ii = page['imageinfo'][0]
    if ii.get('mime') not in ("image/jpeg", "image/png"): return False
    w, h = ii.get('width', 0), ii.get('height', 0)
    if w < min_w or h < min_h: return False
    if w < h * 0.6: return False
    if BAD_WORDS.search(norm_title(page.get('title', ''))): return False
    return True

def passes_aesthetic_filter(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None: return False
    img = cv2.resize(img, (1024, int(img.shape[0] * 1024 / img.shape[1])))
    blur_score = cv2.Laplacian(img, cv2.CV_64F).var()
    if blur_score < 30: return False
    if np.mean(img) < 30: return False
    return True

def build_candidate_pool(subject):
    pool = []
    seen_urls = set()
    WD = "https://www.wikidata.org/w/api.php"
    r = _relay_json(WD, action="wbsearchentities", search=subject, language="en", limit=1)
    qid = r["search"][0]["id"] if r.get("search") else None

    if qid:
        ent = _relay_json(WD, action="wbgetentities", ids=qid, props="claims")
        try:
            p18 = ent["entities"][qid]["claims"]["P18"][0]["mainsnak"]["datavalue"]["value"]
            pool.append({"title": f"File:{p18}", "anchor": True, "imageinfo": [{"url": f"https://commons.wikimedia.org/wiki/Special:FilePath/{urllib.parse.quote(p18)}?width=2560", "width": 2560, "height": 1440, "mime": "image/jpeg"}]})
            seen_urls.add(pool[-1]["imageinfo"][0]["url"])
        except: pass

    WIKI = "https://en.wikipedia.org/w/api.php"
    wr = _relay_json(WIKI, action="query", prop="pageimages", titles=subject, pithumbsize="2560", redirects="1")
    for p in wr.get("query", {}).get("pages", {}).values():
        if "thumbnail" in p:
            url = p["thumbnail"]["source"]
            if url not in seen_urls:
                pool.append({"title": "Wiki Lead", "anchor": True, "imageinfo": [{"url": url, "width": 2560, "height": 1440, "mime": "image/jpeg"}]})
                seen_urls.add(url)

    if qid:
        c = _relay_json(WD, action="wbgetclaims", entity=qid, property="P373")
        try:
            cat = c["claims"]["P373"][0]["mainsnak"]["datavalue"]["value"]
            COMMONS = "https://commons.wikimedia.org/w/api.php"
            cr = _relay_json(COMMONS, action="query", generator="categorymembers", gcmtitle=f"Category:{cat}", gcmtype="file", gcmlimit="30", prop="imageinfo", iiprop="url|size|mime", iiurlwidth="2560")
            for p in cr.get("query", {}).get("pages", {}).values():
                url = p['imageinfo'][0].get('thumburl') or p['imageinfo'][0].get('url')
                if url not in seen_urls:
                    pool.append(p)
                    seen_urls.add(url)
        except: pass

    if len(pool) < 10:
        COMMONS = "https://commons.wikimedia.org/w/api.php"
        sr = _relay_json(COMMONS, action="query", generator="search", gsrsearch=f'filetype:bitmap "{subject}"', gsrnamespace="6", gsrlimit="30", prop="imageinfo", iiprop="url|size|mime", iiurlwidth="2560")
        for p in sr.get("query", {}).get("pages", {}).values():
            url = p['imageinfo'][0].get('thumburl') or p['imageinfo'][0].get('url')
            if url not in seen_urls:
                pool.append(p)
                seen_urls.add(url)
    return pool

BLOCK_TAGS = {"table", "ul", "ol", "dl", "li", "details", "blockquote", "figure", "aside", "nav", "footer", "pre", "header"}
BLOCK_HEADING = re.compile(r"quick\s*facts|faq|frequently asked|sources?|references?|further reading|related|table of contents|conclusion|summary|q&a|bibliography|see also|visitor information", re.I)
BLOCK_CLASS = re.compile(r"faq|quick|facts|source|ref|toc|infobox|related|widget|accordion", re.I)

def curate_images(html_path, output_dir):
    print(f"--- Running Flawless V2 Curator (GPT Section Finder) ---")
    with open(html_path, "r", encoding="utf-8") as f:
        soup = BeautifulSoup(f.read(), "html.parser")
    
    # Wipe ALL existing img_*.jpg images from previous runs
    for div in soup.find_all("div", class_="separator"):
        div.decompose()
    for img in soup.find_all("img"):
        if "img_" in img.get("src", ""):
            img.decompose()
    
    # Wipe ALL existing img_*.jpg images from previous runs
    for div in soup.find_all("div", class_="separator"):
        div.decompose()
    for img in soup.find_all("img"):
        if "img_" in img.get("src", ""):
            img.decompose()
    
    # Wipe ALL existing img_*.jpg images from previous runs
    for div in soup.find_all("div", class_="separator"):
        div.decompose()
    for img in soup.find_all("img"):
        if "img_" in img.get("src", ""):
            img.decompose()
    
    # Remove any existing autopilot images to prevent duplicates
    for div in soup.find_all("div", class_="separator"):
        if div.get("data-autopilot") == "1":
            div.decompose()
    for div in soup.find_all("div", class_="separator"):
        if div.find("img") and not div.get("data-autopilot"):
            # also remove old injected images that might not have the flag
            pass
    
    h1 = soup.find("h1")
    subject = h1.text.split("—")[0].split("|")[0].strip() if h1 else "Unknown"
    
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir, ignore_errors=True)
    os.makedirs(output_dir, exist_ok=True)
    
    # Use GPT's robust section finder
    sections = find_sections(soup)
    print(f"  [curator] Found {len(sections)} eligible sections.")
    
    if not sections:
        print("  ❌ No eligible sections found by section_finder. Returning False.")
        return False
    
    pool = build_candidate_pool(subject)
    print(f"  [curator] Candidate pool size: {len(pool)}")
    
    img_count, hashes = 0, set()
    
    for page in pool:
        if img_count >= len(sections) or img_count >= 7: break
        if not passes_meta_filter(page): continue
        
        url = page['imageinfo'][0].get('thumburl') or page['imageinfo'][0].get('url')
        fd, temp_path = tempfile.mkstemp(prefix="candidate_", suffix=".jpg", dir=output_dir)
        os.close(fd)
        
        try:
            if not download_image(url, temp_path): continue
            if not passes_aesthetic_filter(temp_path): continue
                
            try:
                with Image.open(temp_path) as im:
                    h = str(imagehash.dhash(im.convert("RGB")))
            except Exception:
                continue
                
            if h in hashes: continue
                
            slot = sections[img_count]
            snippet = " ".join(slot['p'].text.split()[:15])
            
            print(f"    [validator] Matching to: '{slot['heading']}'")
            if not contrastive_clip_score(image_path=temp_path, subject=subject, heading=slot['heading'], snippet=snippet):
                continue

            hashes.add(h)
            name = f"img_{img_count+1:02d}.jpg"
            final_path = os.path.join(output_dir, name)
            os.replace(temp_path, final_path)
                
            # Generate a proper description/caption from the paragraph
            p_text = slot['p'].get_text(" ", strip=True)
            # Get the first sentence, up to 150 characters
            caption = p_text.split('.')[0] + '.' if '.' in p_text else slot['heading']
            if len(caption) > 150:
                caption = caption[:147] + "..."
                
            alt = html.escape(caption, quote=True)
            
            # Build custom figure with the descriptive caption
            figure_html = f"""
            <div class="separator" data-autopilot="1" style="clear: both; text-align: center; margin: 24px 0px;">
                <a href="{name}"><img border="0" src="{name}" alt="{alt}" style="width: 100%; max-width: 800px; height: auto; display: block; margin: 0 auto;" /></a>
                <div style="font-style: italic; font-size: 0.9em; color: #555; margin-top: 8px;">{alt}</div>
            </div>
            """
            
            fragment = BeautifulSoup(figure_html, "html.parser")
            new_fig = fragment.find("div", class_="separator")
            slot['p'].insert_after(new_fig)
            
            img_count += 1
            print(f"      ✅ Accepted image {img_count}")
            
        finally:
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass

    if img_count == 0:
        return False

    out_path = os.path.join(output_dir, "_output.html")
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(str(soup))
    return True

def download_image(url, save_path):
    try:
        raw = _relay_get(url)
        with open(save_path, 'wb') as f: f.write(raw)
        return True
    except Exception: return False
