import os
import sys
import shutil
from pathlib import Path
from bs4 import BeautifulSoup

sys.path.append(str(Path(__file__).resolve().parent))
from core.blogger_publisher import publish_post
from core.image_curator import curate_images

V2_ROOT = Path(__file__).resolve().parent
PENDING_DIR = V2_ROOT / "content" / "pending"
PROCESSED_DIR = V2_ROOT / "content" / "processed"
FAILED_DIR = V2_ROOT / "content" / "failed"

def process_post(html_path):
    print(f"\n==================================================")
    print(f"PROCESSING: {html_path.name}")
    print(f"==================================================")
    
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
        
    soup = BeautifulSoup(html_content, 'html.parser')
    h1 = soup.find('h1')
    title = h1.get_text(strip=True) if h1 else html_path.stem.replace('-', ' ').title()
    print(f"  [main] Title: {title}")
    
    img_folder = PROCESSED_DIR / html_path.stem
    
    try:
        success = curate_images(html_path, img_folder)
    except Exception as e:
        print(f"  ❌ Curator crashed: {e}")
        success = False

    if not success:
        print("  ❌ Curator failed to place images. Moving to failed.")
        shutil.move(str(html_path), str(FAILED_DIR / html_path.name))
        return
        
    curated_html_path = img_folder / "_output.html"
    if not curated_html_path.exists():
         print("  ❌ Curated HTML not found. Moving to failed.")
         shutil.move(str(html_path), str(FAILED_DIR / html_path.name))
         return
         
    print(f"\n--- Publishing to Blogger ---")
    success = publish_post(
        html_path=curated_html_path,
        img_folder=img_folder,
        title=title,
        labels=[]
    )
    
    if success:
        shutil.move(str(html_path), str(PROCESSED_DIR / html_path.name))
        print(f"  ✅ SUCCESS: {html_path.name} moved to processed.")
    else:
        shutil.move(str(html_path), str(FAILED_DIR / html_path.name))
        print(f"  ❌ FAILED: {html_path.name} moved to failed.")

def main():
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    FAILED_DIR.mkdir(parents=True, exist_ok=True)

    pending_files = list(PENDING_DIR.glob("*.html"))
    if not pending_files:
        print("No .html files found in pending.")
        return

    print(f"Found {len(pending_files)} HTML posts to process.")
    for i, html_file in enumerate(pending_files, 1):
        print(f"\n[{i}/{len(pending_files)}] Processing {html_file.name}...")
        process_post(html_file)

if __name__ == "__main__":
    main()
