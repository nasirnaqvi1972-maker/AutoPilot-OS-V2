﻿import os
import sys
import json
import base64
import requests
from pathlib import Path
from bs4 import BeautifulSoup
from dotenv import load_dotenv

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

sys.path.append(str(Path(__file__).resolve().parent.parent))
from core.seo_optimizer import SEOOptimizer

load_dotenv()
SCOPES = ['https://www.googleapis.com/auth/blogger']
IMGBB_API_KEY = os.getenv("IMGBB_API_KEY", "ea907fa6f9a48ecf480a0ca77f6a550b") # Default fallback

import pickle

def get_blogger_service():
    """Handles Google OAuth 2.0 Authentication using the V1 pickle token."""
    creds = None
    config_dir = Path(__file__).resolve().parent.parent / 'config'
    token_path = config_dir / 'blogger_token.pickle'
    creds_path = config_dir / 'client_secrets.json'

    if token_path.exists():
        with open(token_path, 'rb') as token:
            creds = pickle.load(token)
            
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not creds_path.exists():
                raise FileNotFoundError(f"Missing {creds_path}. You must authenticate first.")
            flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
            creds = flow.run_local_server(port=0)
            
        with open(token_path, 'wb') as token:
            pickle.dump(creds, token)

    return build('blogger', 'v3', credentials=creds)

def upload_to_imgbb(image_path, api_key):
    """Uploads an image to ImgBB and returns the direct URL."""
    try:
        with open(image_path, "rb") as file:
            payload = {
                "key": api_key,
                "image": base64.b64encode(file.read()).decode('utf-8')
            }
        response = requests.post("https://api.imgbb.com/1/upload", data=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        return data['data']['url']
    except Exception as e:
        print(f"  [publisher] ImgBB upload failed for {image_path}: {e}")
        return None

def publish_post(html_path, img_folder, title, labels, post_id=None):
    print(f"\n--- Publishing to Blogger ---")
    
    # 1. Read HTML
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
        
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # 2. Upload Images and Replace Sources
    img_cache = {}
    for img in soup.find_all('img'):
        src = img.get('src')
        if src and not src.startswith('http'):
            local_img_path = Path(img_folder) / src
            if local_img_path.exists():
                print(f"  [publisher] Uploading {src} to ImgBB...")
                hosted_url = upload_to_imgbb(local_img_path, IMGBB_API_KEY)
                if hosted_url:
                    img['src'] = hosted_url
                    img_cache[src] = hosted_url
                    print(f"    ✅ URL: {hosted_url}")
            else:
                print(f"  [publisher] Missing local image: {src}. Removing figure.")
                fig = img.find_parent('figure')
                if fig: fig.decompose()
                else: img.decompose()

    # 3. Apply SEO Optimizations
    print("  [publisher] Applying SEO Optimizations...")
    optimizer = SEOOptimizer(str(soup))
    optimizer.clean_headings().inject_schema_markup(title).optimize_images()
    
    meta_description = optimizer.get_meta_description()
    final_html = optimizer.get_html()
    
    # 4. Connect to Blogger
    print("  [publisher] Connecting to Blogger API...")
    service = get_blogger_service()
    blog = service.blogs().getByUrl(url='https://dustanddynasty.blogspot.com').execute()
    blog_id = blog['id']
    
    # 5. Prepare the Payload
    body = {
        "kind": "blogger#post",
        "title": title,
        "content": final_html,
        "labels": labels or [],
        "searchDescription": meta_description
    }
    
    # 6. Insert or Patch
    try:
        if post_id:
            print(f"  [publisher] Updating existing draft (ID: {post_id})...")
            result = service.posts().patch(blogId=blog_id, postId=post_id, body=body).execute()
        else:
            print("  [publisher] Creating a brand new draft...")
            result = service.posts().insert(blogId=blog_id, body=body, isDraft=True).execute()
            
        print(f"  ✅ SUCCESS! Post ID: {result['id']}")
        print(f"  🔗 URL: {result['url']}")
        return result['id']
        
    except Exception as e:
        print(f"  ❌ FAILED to publish: {e}")
        return None
